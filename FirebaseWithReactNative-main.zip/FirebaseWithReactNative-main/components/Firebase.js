import { initializeApp } from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyA7eHk4ei_6Y_wU4_TeCsQXTmwnG6vv_qg", 
  authDomain: "acessobdloja.firebaseapp.com",
  projectId: "acessobdloja",
  storageBucket: "acessobdloja.appspot.com", 
  messagingSenderId: "125820498288",
  appId: "1:125820498288: web:66d27727a6f8e78f035fb5"
};

const app = initializeApp(firebaseConfig);

export default app;